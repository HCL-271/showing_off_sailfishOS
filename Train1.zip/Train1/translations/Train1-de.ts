<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>1</name>
    <message>
        <source>Вернуться</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Anketa_Page</name>
    <message>
        <source>Ну я же просил :(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Вернуться</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoverPage</name>
    <message>
        <source>Здравствуй, заполни анкету</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <source>My name is Van. I&apos;m an artist. A perfomance artist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Перейти на страницу с анкетой</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cделано в России</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Заполняй анкету
Ща поберем тебе соседей</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Search_window</name>
    <message>
        <source>
Поиск</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecondPage</name>
    <message>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecondPage_копия</name>
    <message>
        <source> 
 
 </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
